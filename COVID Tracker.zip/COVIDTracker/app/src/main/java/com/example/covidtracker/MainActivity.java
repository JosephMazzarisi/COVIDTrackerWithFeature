package com.example.covidtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements android.view.View.OnClickListener {
    RadioButton radioButton1;
    RadioButton radioButton2;
    RadioButton radioButton3;
    RadioButton radioButton4;
    RadioButton radioButton5;
    RadioButton radioButton6;
    RadioButton radioButton7;
    RadioButton radioButton8;
    RadioButton radioButton9;
    RadioButton radioButton10;

    RadioGroup radioGroup1;
    RadioGroup radioGroup2;
    RadioGroup radioGroup3;
    RadioGroup radioGroup4;
    RadioGroup radioGroup5;
    TextView View1;
    TextView View2;
    TextView View3;
    TextView View4;
    TextView View5;
    TextView View6;

    TextView textName;
    Button button1;
    boolean textName2;
    boolean group1,group2,group3,group4,group5;
    boolean yesOne,yesTwo,yesThree,yesFour,yesFive;
    boolean noOne,noTwo,noThree,noFour,noFive;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioButton1 = findViewById(R.id.yesOne);
        radioButton2 = findViewById(R.id.noOne);
        radioButton3 = findViewById(R.id.yesTwo);
        radioButton4 = findViewById(R.id.noTwo);
        radioButton5 = findViewById(R.id.yesThree);
        radioButton6 = findViewById(R.id.noThree);
        radioButton7 = findViewById(R.id.yesFour);
        radioButton8 = findViewById(R.id.noFour);
        radioButton9 = findViewById(R.id.yesFive);
        radioButton10 = findViewById(R.id.noFive);
        View1 = findViewById(R.id.titleText);
        View2 = findViewById(R.id.questionOne);
        View3 = findViewById(R.id.questionTwo);
        View4 = findViewById(R.id.questionThree);
        View5 = findViewById(R.id.questionFour);
        View6 = findViewById(R.id.questionFive);

        radioButton1.setOnClickListener(this);
        radioButton2.setOnClickListener(this);
        radioButton3.setOnClickListener(this);
        radioButton4.setOnClickListener(this);
        radioButton5.setOnClickListener(this);
        radioButton6.setOnClickListener(this);
        radioButton7.setOnClickListener(this);
        radioButton8.setOnClickListener(this);
        radioButton9.setOnClickListener(this);
        radioButton10.setOnClickListener(this);
        radioGroup1.setOnClickListener(this);
        radioGroup2.setOnClickListener(this);
        radioGroup3.setOnClickListener(this);
        radioGroup4.setOnClickListener(this);
        radioGroup5.setOnClickListener(this);

        textName = findViewById(R.id.nameText);
        button1 = findViewById(R.id.buttonSubmit);

    }

    /*public void launchSecondActivity(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
    }*/

    @Override
    public void onClick(View view) {
        if(radioGroup1.getCheckedRadioButtonId()==-1) {
            group1 = false;
        }
        else {
            if(radioButton1.getId() == radioGroup1.getCheckedRadioButtonId()) {
              yesOne = true;
            }
            else {
              noOne = true;
            }
        }
        if(radioGroup2.getCheckedRadioButtonId()==-1) {
           group2 = false;
        }
        else {
            if(radioButton2.getId() == radioGroup2.getCheckedRadioButtonId()) {
                yesTwo = true;
            }
            else {
                noTwo = true;
            }
        }
        if(radioGroup3.getCheckedRadioButtonId()==-1) {
            group3 = false;
        }
        else {
            if(radioButton3.getId() == radioGroup3.getCheckedRadioButtonId()) {
                yesThree = true;
            }
            else {
                noThree = true;
            }
        }
        if(radioGroup4.getCheckedRadioButtonId()==-1) {
            group4 = false;
        }
        else {
            if(radioButton4.getId() == radioGroup4.getCheckedRadioButtonId()) {
                yesFour = true;
            }
            else {
                noFour = true;
            }
        }
        if(radioGroup5.getCheckedRadioButtonId()==-1) {
            group5 = false;
        }
        else {
            if(radioButton5.getId() == radioGroup5.getCheckedRadioButtonId()) {
                yesFive = true;
            }
            else {
                noFive = true;
            }
        }
        if(!textName.getText().equals("")) {
            textName2 = true;
        }
        else {
            textName2 = false;
        }

        }
    }


